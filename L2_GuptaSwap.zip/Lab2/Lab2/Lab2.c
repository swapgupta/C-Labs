/*********************************************** 
Name: Swap Gupta** 
Date: 01/24/2018** 
Assignment: Lab 2
************************************************* 
Write a C program that reads the input file and 
outputs Hello <name> and if the name has any 
repeated characters.
************************************************/
#include <stdio.h> 
#include <string.h> 
#include <stdlib.h>

char response(char[]);

int main() {
	char input[100];
	char name[100];
	char yn[3];
	FILE *fp;
		fopen_s(&fp, "names.txt", "r");
	if (fp != NULL) { 
		while (fgets(input, 100, fp) != NULL) {
			char *token = strtok_s(input, " \n", &token);
			strcpy_s(name, 100, token);

			char ans = response(name);

			if (ans == 'n') {
				printf("Hello %s, (no)\n", name);
			}
			else if (ans == 'y') {
				printf("Hello %s, (yes)\n", name);
			}
			else {
				printf("error\n");
			}
		}
	}
	else {
		printf("Error opening file\n");
	}

	fclose(fp);
	getchar();
	return 0;
}

char response(char name[100]) {
	char yn = 'n';
	int count = sizeof(name);
	for (int i = 0; i < count - 1; i++) {
		for (int j = i + 1; j < count; j++) {
			if (name[i] == name[j]) {
				yn = 'y';
			}
		}
	}
	return yn;
}