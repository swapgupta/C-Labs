/* Lab 1
Swap Gupta
*/
#include <stdio.h>

int calc(int, int);

int globalBase; //the global base
int globalPower; //the global power
int result; //the result

//This is the main function
int main() {
	printf("Enter the base and then the power, separated by a space: ");
	scanf_s("%d %d", &globalBase, &globalPower);

	if (globalBase < 0 || globalPower < 0) {
		printf("Error");
	}
	else if (globalBase == 0 && globalPower == 0) {
		printf("Error");
	}
	else {
		result = calc(globalBase, globalPower);
		printf("The result is: %d", result);
	}

	return 0;
}

//This function is used to calculate the value
int calc(int base, int power) {

	if (power == 0) {
		return 1;
	}
	else {
			return base * calc(base, power - 1);
	}

}